/*
 * update_particle.h
 *
 */

#ifndef UPDATE_PARTICLE_H_
#define UPDATE_PARTICLE_H_

void update_w(std::vector<LPParticle> Particle_Set, std::vector<double>& w, double lambda, double xi);


#endif /* UPDATE_PARTICLE_H_ */
